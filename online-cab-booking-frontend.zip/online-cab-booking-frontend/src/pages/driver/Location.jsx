import { useState, useEffect } from "react";
import { toast } from "react-toastify";
import useAuth from "../../hooks/useAuth";
import { getDriverByUserId, updateDriverLocation } from "../../services/driverService";

export default function Location() {
  const { userId } = useAuth();
  const [driverId, setDriverId] = useState(null);
  const [latitude, setLatitude] = useState("");
  const [longitude, setLongitude] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadDriver = async () => {
      const res = await getDriverByUserId(userId);
      if (res.success) {
        setDriverId(res.data.id);
        setLatitude(res.data.location?.latitude ?? "");
        setLongitude(res.data.location?.longitude ?? "");
      } else {
        toast.error(res.message);
      }
      setLoading(false);
    };
    loadDriver();
  }, [userId]);

  const handleUpdate = async () => {
    setSaving(true);
    const res = await updateDriverLocation(driverId, parseFloat(latitude), parseFloat(longitude));
    setSaving(false);

    if (res.success) {
      toast.success(res.message || "Location updated");
    } else {
      toast.error(res.message);
    }
  };

  if (loading) return <p className="p-6 text-gray-500">Loading location...</p>;

  return (
    <div className="max-w-2xl">
      <h1 className="text-2xl font-bold text-gray-900 mb-1">Driver location</h1>
      <p className="text-gray-500 text-sm mb-6">Share your live location with dispatch.</p>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 space-y-4">
        <div>
          <label className="text-xs font-semibold text-gray-500">Latitude</label>
          <input
            value={latitude}
            onChange={(e) => setLatitude(e.target.value)}
            className="w-full mt-1 border border-gray-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-gray-500">Longitude</label>
          <input
            value={longitude}
            onChange={(e) => setLongitude(e.target.value)}
            className="w-full mt-1 border border-gray-200 rounded-lg px-3 py-2 text-sm"
          />
        </div>

        <button
          onClick={handleUpdate}
          disabled={saving}
          className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold px-5 py-2.5 rounded-lg hover:opacity-90 disabled:opacity-60"
        >
          {saving ? "Updating..." : "Update location"}
        </button>
      </div>
    </div>
  );
}